function [x,y] = L03circle_fct(r,filename);
% CIRCLE Draw a circle of radius r
% Syntax: [x,y]=L03circle_fct(r,filename);
% or L04circle_fct(r,filename);
% Input: r, the radius and
% filename, the file to save the jpg image to
% Output [x,y] - the x and y coordinates of the circle points
%
theta=linspace(0,2*pi,100);  % create vector theta
x=r*cos(theta);              % generate x coordinates
y=r*sin(theta);              % generate y coordinates
plot(x,y);                   % plot the circle
axis('equal');               % set equal scale on axes
title(['Circle of radius r=',num2str(r)]); % put title on graph
print('-djpeg',filename);
end % L03circle_fct
