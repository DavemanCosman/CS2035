function factn=L03factorial(n);
% FACTORIAL: function to compute factorial
% Call Syntax: factn=L03factorial(n)
if n < 0  % If n is negative factorial is undefined
error('n is negative - factorial undefined')
elseif n==0 | n==1
factn=1; % 0! is defined to be 1
else % n > 1
fprintf('%d ',n);
factn=n*L03factorial(n-1);
end % if
end % L03factorial
