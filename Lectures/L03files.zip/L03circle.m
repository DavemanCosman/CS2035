% CIRCLE - a script file to draw a unit circle
% -----------------------------------------------
theta=linspace(0,2*pi,100); % generate 100 linearly spaced elements
                            % from 0 to 2pi and save is array theta
x=cos(theta);  % x is a 100 element long vector of cos(theta) terms
y=sin(theta);
plot(x,y);     % plot x versus y elements (a circle)
axis('equal'); % set the length scales of the 2 axes to be the same
xlabel('x');   % label the x axis with x
ylabel('y');   % label the y axis with y
title('Circle of unit radius'); % put title on graph
print('-djpeg','circle.jpg');
